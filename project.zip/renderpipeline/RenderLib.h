//
// Created by olegb on 11.11.2025.
//

#pragma once
#include "ColorEngine.h"

#ifndef GAMEINCONSOLE_RENDERLIB_H
#define GAMEINCONSOLE_RENDERLIB_H

#endif //GAMEINCONSOLE_RENDERLIB_H

#include <windows.h>

//Render library

//When using this library for your projects make sure to set up it here
//this is the default
//int MaxScreenX = 100;
//int MaxScreenY = 17;
//


int MaxScreenX = 50;
int MaxScreenY = 29;
int CounterColor = 0;
float sizefix = 2.5;

// Functions

// Fill screen
// Usage

void fillscreen(const int ColorType) {
    for (int i = 0; i < MaxScreenY; i++) {
        for (int j = 0; j < MaxScreenX; j++) {
            if (ColorType == 1) {
                if (CounterColor == 0) {
                    std::cout << "#";
                    CounterColor++;
                }
                else if (CounterColor == 1) {
                    std::cout << "$";
                    CounterColor++;
                }
                else if (CounterColor == 2) {
                    std::cout << "*";
                    CounterColor++;
                }
                else if (CounterColor == 3) {
                    std::cout << "%";
                    CounterColor = 0;
                }
            }
            else {
                std::cout << "@";
            }

        }
        std::cout << std::endl;
    }
}

void drawline(const int amount,const char character) {
    for (int j = 0; j < amount; j++) {
        std::cout << character;
    }

}

//Render a cube

HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

void drawcube(const float cubesize,const int MoveXBy,const int MoveYBy) {
    float cubex = 2;
    float cubey = 2;
    for (int h = 0; h < MoveYBy; h++) {
        std::cout << std::endl;
    }
    for (int i = 0; i < (cubey * cubesize); i++) {
        SetConsoleTextAttribute(hConsole, 0);
        for (int k = 0; k < MoveXBy; k++) {
            std::cout << " ";
        }
        SetConsoleTextAttribute(hConsole, 24);
        drawline((cubex * sizefix) * cubesize,*"@");
        SetConsoleTextAttribute(hConsole, 0);
        std::cout << std::endl;
    }
}

