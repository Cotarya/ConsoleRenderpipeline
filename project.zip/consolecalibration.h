//
// Created by olegb on 12.11.2025.
//

#ifndef GAMEINCONSOLE_CONSOLECALIBRATION_H
#define GAMEINCONSOLE_CONSOLECALIBRATION_H

#endif //GAMEINCONSOLE_CONSOLECALIBRATION_H

void calibrate() {
    for (int i = 0; i < 100; i++) {
        std::cout << i << std::endl;
    }
}