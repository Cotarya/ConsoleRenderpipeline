#include <iostream>
#include <string>
#include "renderpipeline/RenderLib.h"
#include "renderpipeline/ColorEngine.h"
#include "consolecalibration.h"
#include <thread>
#include <chrono>



//Project info:
//Name: Game in console c++
//Run in console!!!

int main() {
    for (true == true; true;) {
        system("cls");
        drawcube(4,2,2);
        std::this_thread::sleep_for(std::chrono::seconds(1)); //So it wont look bad in console
    }
}